---
layout: post
title: Markdown Guide
subtitle: Resources to work with Markdown
categories: markdown
tags: [guide, markdown]
---

## Resources

This is a [good guide](https://www.markdownguide.org/basic-syntax/) to learn about the basic markdown syntax.