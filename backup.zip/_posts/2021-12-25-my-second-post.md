---
layout: post
title: Introduction to Python
subtitle: Each post also has a subtitle
categories: Python
tags: [Python, intro, certificate]
---

## Introduction to Python

This post is meant to summarize some of the key concepts I have learned in the course *Introduction to Python*


![datacamp certification](/assets/images/banners/datacamp_certificate_dummy.jpg)